def add_one(number):
    return number + 1

def capstone():
    print("Hello World\n")
    print("This is the start of my Senior Capstone project !\n")
